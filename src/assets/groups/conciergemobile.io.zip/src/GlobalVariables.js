
class GlobalVariables {

	constructor() {
		this.globalUrl = 'https://conciergemobile.io/';
		this.token = "vDQEQe7bIL25BWUHCM6EO7f03xaeCKnzNIvoHzgh824w0Zsi5iBAwO2zmsuPHv1cdPBOH6WEsX8vFXaVgtVgmOOCr3ey708iFQDNfhjWkQWVDWvHLC6v6FvZrlmR02lwgizaXURcJhZimDRlSGboknB4QFA0ID4D49WfX_AUSp-cCIZY5eFbxBvhHzqAuEXG0AZvFjjNKYZoaZMGREDC1DVl9zkpPDzbI66_jFy3GQUBw4bv8u39K1I7Fk5x5pCKviR0CbY_CzgCJDJJ0tqthVPozE5xWTEli2nKJGcJRahVgn5N3iwegn1jXcD9UAGqbweReU6xDdBBM-RJxLncwGWE8JPPX-R6yhuWNr70uUgAmZ1_dCE52RZL_rbRasUOFTixcwYrurr1_PrHumBmsfimKK5wGaQlFOISyVQDUT7k_vJAD_nG2o8JIwHHXHh6hkaNsz-6JK0iktv-78qOSyJjmIl88YGCptzhuqLz1avAiAmFwlPHdOVd9u0BWS4WCgJ89aSwWlEmlQVEeqlqNg";
	}

	getRequest(url) {
		return this.sendRequest('GET', url, null, null)
	};

	postRequest(url, data) {
		return this.sendRequest('POST', url, data, null);
	};

	postJson(url, data) {
		return this.sendRequest('POST', url, JSON.stringify(data), 'application/json');
	};

	putRequest(url, data, type = null) {
		return this.sendRequest('PUT', url, data, type);
	};

	deleteRequest(url) {
		return this.sendRequest('DELETE', url, null, null);
	};

	sendRequest(method, url, data, contentType) {
		contentType = contentType ? contentType : 'application/x-www-form-urlencoded';
		let token = this.token;

		return fetch(this.globalUrl+url, {
			method: method,
			headers: {
				'Content-Type' : contentType,
				'Authorization' : 'Bearer ' + token
			},
			body: data
		})
	}
}

export default new GlobalVariables();