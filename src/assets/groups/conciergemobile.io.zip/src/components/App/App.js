import React from 'react';
import '../../css/App/App.css';
import Sidebar from "../Sidebar/Sidebar";
import Window from "../Window/Window";
import GlobalVariables from "../../GlobalVariables";
import { hubConnection } from 'signalr-no-jquery';

class App extends React.Component {
	constructor(props) {
		super();
		this.state = {
			activeUser: null,
			users: {},
			newMessages: {
				userIds: [],
				info: []
			}
		};
		this.changeCurrentUser = this.changeCurrentUser.bind(this);
		this.removeReadedMessage = this.removeReadedMessage.bind(this);
	}

	componentWillMount() {
		GlobalVariables.getRequest('api/v1/users/usersbycategories')
			.then((response) => {
				return response.json();
			})
			.then(response => {
				this.setState({
					users: response
				})
			})
			.catch((error) => {
				alert(error)
			});
	}

	componentDidMount() {
		const connection = hubConnection('https://conciergemobile.io/signalr');
		const hubProxy = connection.createHubProxy('chathub');

	// set up event listeners i.e. for incoming "message" event
		hubProxy.on('broadcastMessage', (name, message) => {
			let json = JSON.parse(message);
			let userId = json.userId;
			let newObj = {
				userIds: this.state.newMessages.userIds.concat(userId),
				info: this.state.newMessages.info.concat(json)
			};
			this.setState({
				newMessages: newObj,
			})
		});

	// connect
		connection.start({ jsonp: true })
			.done(function(){ console.log('Now connected, connection ID=' + connection.id); })
			.fail(function(){ alert('Could not connect to socket'); });
	}


	removeReadedMessage(readed) {
		let newObj = {
			userIds: this.state.newMessages.userIds.filter(e => e !== readed),
			info: this.state.newMessages.info.filter(e => e.userIds !== readed)
		};
		this.setState({
			newMessages: newObj
		})
	}

	changeCurrentUser(userId) {
		let activeUser = null;
		Object.keys(this.state.users).forEach((key) => {
			let user = this.state.users[key].find(user => {
				return userId === user.Id;
			});
			if (user)
				activeUser = user;
		});
		this.setState({
			activeUser: activeUser
		})
	}

	render() {
		return (
			<div className="App container-fluid">
				<div className="row">
					{Object.keys(this.state.users).length > 0 &&
						<Sidebar users={this.state.users} activeUser={this.state.activeUser} changeCurrentUser={this.changeCurrentUser} newMessage={this.state.newMessages}/>}
					{this.state.activeUser &&
						<Window activeUser={this.state.activeUser} changeCurrentUser={this.changeCurrentUser} newMessage={this.state.newMessages} removeReadedMessage={this.removeReadedMessage}/>
					}
				</div>
			</div>
			);
		}
	}

export default App;
