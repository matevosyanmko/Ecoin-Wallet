import React from 'react';
import "../../css/Chat/Chat.css"

class ChatRooms extends React.Component {


	render() {
		let chatHistory;
		chatHistory = this.props.chatHistory.map((message) => {
			let classNames = "rooms";
			return (
				<div className={classNames} key={message.Id} onClick={() => this.props.changeRoomsToChat(message)}>
					<strong className="w-100 d-block">Тема: {message.Text}</strong>
					Дата создания: {message.time} | Ответов: {message.Replies}
				</div>
			);
		});


		return (
			<div className="ChatRooms">
				<div className="roomsWindow col-12">
					{chatHistory}
				</div>
			</div>
		)
	}
}

export default ChatRooms;