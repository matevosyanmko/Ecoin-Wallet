import React from 'react';
import "../../css/Chat/Chat.css"
import ChatForm from "./ChatForm";

class Chat extends React.Component {

	componentDidMount() {
		this.chat.scrollTop = this.chat.scrollHeight;
	}

	render() {
		let lastDate = null;
		let addNewDate = false;

		let chatHistory = this.props.chatHistory.map((message) => {
			let classNames = "message";
			if (this.props.activeUser.Id !== message.UserId) {
				classNames = classNames + " operator-message";
			}
			if (lastDate !== message.date) {
				lastDate = message.date;
				addNewDate = true;
			}
			return (
				<div className={classNames} key={message.Id}>
					{addNewDate &&
						<div className="newDayLine">
							<span>{message.date}</span> {addNewDate = false}
						</div>
					}
					<div className="text">
						<p>{message.Text}</p>
					</div>
					<div className="info">
						{message.time}
					</div>
				</div>
			);
		});

		return (
			<div className="chatRoom">
				<div className="theme d-flex justify-content-between align-items-center">
					<h4>{this.props.parentMessage.Text}</h4>
					<div className="close" onClick={() => this.props.backToRooms()}>
						&times;
					</div>
				</div>
				<div className="chatWindow" ref={(ref) => this.chat = ref}>
					{chatHistory}
				</div>
				<ChatForm changeRoomsToChat={this.props.changeRoomsToChat} activeUser={this.props.activeUser} parentMessage={this.props.parentMessage}/>
			</div>
		)
	}
}

export default Chat;