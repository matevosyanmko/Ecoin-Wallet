import React from 'react';
import "../../css/Chat/Chat.css"
import GlobalVariables from "../../GlobalVariables";

class ChatForm extends React.Component {
	constructor() {
		super();
		this.state = {
			value: ''
		};

		this.handleChange = this.handleChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
	}

	handleChange(event) {
		this.setState({value: event.target.value});
	}

	sendMessage() {
		this.props.changeRoomsToChat(this.props.parentMessage);
	}

	handleSubmit(event) {
		let data = {
			"UserId" : this.props.activeUser.Id,
			"Text" : this.state.value
		};
		data = Object.keys(data).map(key => encodeURIComponent(key) + '=' + encodeURIComponent(data[key])).join('&');
		GlobalVariables.postRequest('api/v1/main/messages/' + this.props.parentMessage.Id + '/reply', data)
			.then((response) => {
				alert('Отправленно');
				this.sendMessage();
			})
			.catch((error) => {
				alert(error)
			});
		event.preventDefault();
	}

	render() {
		return (
			<div className="ChatForm">
				<form onSubmit={(event) => this.handleSubmit(event)}>
					<div className="form-group row">
						<div className="col-10">
							<textarea className="form-control" rows="5" value={this.state.value} onChange={(event) => this.handleChange(event)}/>
						</div>
						<div className="col-2">
							<input className="btn btn-primary w-100" type="submit" value="Submit"/>
						</div>
					</div>
				</form>
			</div>
		)
	}
}
export default ChatForm;