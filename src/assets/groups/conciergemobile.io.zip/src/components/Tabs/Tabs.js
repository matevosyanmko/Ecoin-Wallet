import React from 'react';
import GlobalVariables from "../../GlobalVariables";
import ChatRooms from "../Chat/ChatRooms";
import Chat from "../Chat/Chat";
import Order from "../Order/Order";
import CreateOrder from "../Order/CreateOrder";
import Info from "../User/Info";
import "../../css/Tabs/Tabs.css"

class Tabs extends React.Component {

	constructor() {
		super();

		this.state = {
			currentWindow: "room",
			chatHistory: [],
			currentUserId: null,
			currentChat: null,
			parentMessage: null,
			orders: null
		};

		this.onChangeCurrentWindow = this.onChangeCurrentWindow.bind(this);
		this.changeRoomsToChat = this.changeRoomsToChat.bind(this);
		this.backToRooms = this.backToRooms.bind(this);
	}

	checkRooms() {
		GlobalVariables.getRequest('api/v1/users/' + this.props.activeUser.Id + '/messages')
			.then((response) => {
				return response.json();
			})
			.then((chatHistory) => {
				return chatHistory.sort(function(a, b) {
					if (a.DateCreated > b.DateCreated)
						return -1;
					if (a.DateCreated < b.DateCreated)
						return 1;
					return 0
				});
			})
			.then((chatHistory) => {
				return chatHistory.map((message) => {
					let date = new Date(message.DateCreated);
					message.time = date.toLocaleDateString('ru-RU', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' , hour: '2-digit', minute: '2-digit', second: '2-digit'});
					return message;
				});
			})
			.then((chatHistory) => {
				this.setState({
					chatHistory: chatHistory,
					currentUserId: this.props.activeUser.Id,
					currentChat: null,
					parentMessage: null,
					orders: null,
					currentWindow: "room"
				})
			})
			.catch((error) => {
				alert(error)
			});
	}

	checkMessages(chat) {
		GlobalVariables.getRequest('api/v1/users/' + this.props.activeUser.Id + '/messages/' + chat.Id)
			.then((response) => {
				return response.json()
			})
			.then((chatHistory) => {
				return chatHistory.sort(function(a, b) {
					if (a.DateCreated > b.DateCreated)
						return 1;
					if (a.DateCreated < b.DateCreated)
						return -1;
					return 0
				});
			})
			.then((chatHistory) => {
				return chatHistory.map((message) => {
					let date = new Date(message.DateCreated);
					message.time = date.toTimeString().split(" ")[0];
					message.date = date.toLocaleDateString('ru-RU', {month: 'long', day: 'numeric'});
					return message;
				});
			})
			.then((chatHistory) => {
				this.setState({
					chatHistory: chatHistory,
					currentWindow: "chat",
					currentChat: chat.Id,
					parentMessage: chat
				})
			})
			.catch((error) => {
				alert(error)
			});
	}

	checkOrders() {
		GlobalVariables.getRequest('api/v1/operator/client/'+ this.props.activeUser.Id +'/orders')
			.then((response) => {
				return response.json()
			})
			.then((response) => {
				if (!response.length) {
					response = [];
				}
				this.setState({
					orders: response
				})
			})
			.catch((error) => {
				alert(error)
			});
	}


	componentWillUpdate(nextProps, nextState, nextContent) {
		if (nextProps.activeUser.Id !== this.state.currentUserId) {
			return this.checkRooms();
		}
		if (nextState.currentWindow === "historyOrder") {
			return this.checkOrders();
		}
		if (nextProps.newMessage.userIds.includes(this.props.activeUser.Id)) {
			this.props.removeReadedMessage(nextProps.activeUser.Id);

			if (this.state.currentWindow === 'chat' && nextState.currentWindow === 'chat') {
				return nextProps.newMessage.info.forEach(user => {
					if (user.chatRoomID === nextState.currentChat) {
						this.changeRoomsToChat(nextState.parentMessage);
					}
				});
			}

			nextProps.newMessage.info.forEach(user => {
				if (user.userId === this.props.activeUser.Id) {
					let parentMessage = nextState.chatHistory.filter(e => e.Id === user.chatRoomID);
					return this.changeRoomsToChat(parentMessage[0]);
				}
			});
		}
	}

	shouldComponentUpdate(nextProps, nextState, nextContent) {
		if (this.state.currentWindow === "historyOrder" && nextState.currentWindow === this.state.currentWindow && this.state.orders && this.state.orders.length >= 0 && nextProps.activeUser.Id === this.state.currentUserId) {
			return false;
		}
		return true;
	}

	componentWillMount() {
		this.checkRooms();
	}

	changeRoomsToChat(chat) {
		this.checkMessages(chat);
	}

	backToRooms() {
		this.checkRooms();
	}


	returnComponentForWindow() {
		switch (this.state.currentWindow) {
			default:
				return (
					<div className="error">
						"Error, sorry"
					</div>
				);
			case "chat":
				return (
					<div className="Chat">
						<Chat parentMessage={this.state.parentMessage} chatHistory={this.state.chatHistory} changeRoomsToChat={this.changeRoomsToChat} activeUser={this.props.activeUser} backToRooms={this.backToRooms}/>
					</div>
				);
			case "room":
				return (
					<div className="ChatRooms">
						<ChatRooms chatHistory={this.state.chatHistory} activeUser={this.props.activeUser} changeRoomsToChat={this.changeRoomsToChat}/>
					</div>
				);
			case "historyOrder":
				return (
					<Order orderHistory={this.state.orders}/>
				);
			case "createOrder":
				return (
					<div className="createOrder">
						<CreateOrder activeUser={this.props.activeUser}/>
					</div>
				);
			case "infoUser":
				return (
					<div className="infoUser">
						<Info activeUser={this.props.activeUser}/>
					</div>
				);
		}
	}

	onChangeCurrentWindow(windowName) {
		windowName = (this.state.currentChat && windowName === "room") ? "chat" : windowName;
		this.setState({
			currentWindow: windowName
		})
	}

	render() {
		return (
			<div className="tabs">
				<ul className="nav">
					<li className="nav-item">
						<a className={(this.state.currentWindow === "room" || this.state.currentWindow === "chat") ? "nav-link active" : 'nav-link'} onClick={() => this.onChangeCurrentWindow('room')}>Чат</a>
					</li>
					<li className="nav-item">
						<a className={(this.state.currentWindow === "createOrder") ? "nav-link active" : 'nav-link'} onClick={() => this.onChangeCurrentWindow('createOrder')}>Создать заказ</a>
					</li>
					<li className="nav-item">
						<a className={(this.state.currentWindow === "infoUser") ? "nav-link active" : 'nav-link'} onClick={() => this.onChangeCurrentWindow('infoUser')}>Информация о клиенте</a>
					</li>
					<li className="nav-item">
						<a className={(this.state.currentWindow === "historyOrder") ? "nav-link active" : 'nav-link'} onClick={() => this.onChangeCurrentWindow('historyOrder')}>История заказов</a>
					</li>
				</ul>
				<div className="currentWindow">
					{this.returnComponentForWindow()}
				</div>
			</div>
		);
	}
}

export default Tabs;