import React from 'react';
import "../../css/Window/Window.css"
import Tabs from "../Tabs/Tabs";

class Window extends React.Component {

	constructor(props) {
		super();

		this.state = {};
	}

	render() {
		let className = (this.props.callStatus === "call") ? "Window col-7 offset-3" : "Window col-9 offset-3";
		return (
			<div className={className}>
				<div className="title d-flex justify-content-between align-items-center">
					<h4>{this.props.activeUser.FirstName + " " + this.props.activeUser.LastName} {this.props.userIsBanned && "(banned)"}</h4>
					<div className="buttons">
						<div className="close" onClick={() => this.props.changeCurrentUser(null)}>
							&times;
						</div>
					</div>
				</div>
				<Tabs forceReRender={this.props.forceReRender} userIsBanned={this.props.userIsBanned} activeUser={this.props.activeUser} newMessage={this.props.newMessage} removeReadedMessage={this.props.removeReadedMessage}/>
			</div>
		);
	}
}

export default Window;