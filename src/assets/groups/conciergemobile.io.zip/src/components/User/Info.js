import React from 'react';
import '../../css/User/Info.css';
import noImage from '../../media/no-image.png';

class Info extends React.Component {
	constructor(props) {
		super();
		this.state = {
			value: ""
		};

		this.handleChange = this.handleChange.bind(this);
	}

	handleChange(event) {
		this.setState({value: event.target.value});
	}

	render() {
		let image = (this.props.activeUser.Photo) ? this.props.activeUser.Photo : noImage;
		return (
			<div className="UserInfo">
				<div className="container-fluid">
					<div className="row">
						<div className="col-3">
							<img className="img-fluid rounded" src={image} alt={this.props.activeUser.Name}/>
						</div>
						<div className="col-9 info">
							<div className="row">
								<div className="col-3">
									Имя:
								</div>
								<div className="col-9">
									{this.props.activeUser.FirstName} {this.props.activeUser.LastName}
								</div>
							</div>
							<div className="row">
								<div className="col-3">
									Email:
								</div>
								<div className="col-9">
									{this.props.activeUser.Email}
								</div>
							</div>
							<div className="row">
								<div className="col-3">
									Адрес:
								</div>
								<div className="col-9">
									{this.props.activeUser.Country} {this.props.activeUser.Address}
								</div>
							</div>
							<div className="row">
								<div className="col-3">
									Текущее местоположение:
								</div>
								<div className="col-9">
									{this.props.activeUser.Latitude} {this.props.activeUser.Longitude}
								</div>
							</div>
							<div className="row">
								<div className="col-3">
									Номер телефона:
								</div>
								<div className="col-9">
									{this.props.activeUser.Phone}
								</div>
							</div>
						</div>
					</div>
				</div>
				<hr/>
				<div className="container-fluid">
					<h4>Полезная информация полученая оператором в ходе комуникаций с клиентом / Заметки</h4>
					<form onSubmit={(event) => this.handleSubmit(event)}>
						<div className="form-group row">
							<div className="col-9">
								<textarea defaultValue={this.state.value} className="form-control" id="NotesForm" name="NotesForm" rows="12"/>
							</div>
						</div>
						<input type="submit" className="btn btn-primary"/>
					</form>
				</div>
			</div>
		)
	}
}

export default Info;