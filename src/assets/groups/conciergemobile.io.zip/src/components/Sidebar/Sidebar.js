import React from 'react';
import "../../css/Sidebar/Sidebar.css";

class Sidebar extends React.Component {
	constructor(props) {
		super();
		this.users = {};
		this.sessionNewMessage = [];
		this.state = {
			showed: []
		};
	}

	sort() {
		this.users = Object.assign({newMessage: []}, this.props.users);
		this.sessionNewMessage = [...new Set([...this.sessionNewMessage, ...this.props.newMessage.userIds])];
		Object.keys(this.users).forEach(key => {
			this.users[key].forEach(user => {
				if (this.sessionNewMessage.includes(user.Id)) {
					this.users.newMessage.push(user);
				}
			});
		});
	}

	catName(name) {
		switch (name) {
			case "newMessage": return 'Новые сообщения';
			case "clients": return 'Клиенты';
			case "drivers": return 'Таксисты';
			case "providers": return 'Исполнители';
			default: return undefined;
		}
	};

	clickFunc(name) {
		if (!this.state.showed.includes(name)) {
			this.setState({
				showed: this.state.showed.concat([name])
			})
		} else {
			this.setState({
				showed: this.state.showed.filter(item => item !== name)
			})
		}
	}

	render() {
		this.sort();
		const categories = Object.keys(this.users).map(key => {
			const catUsers = this.users[key].map(user => {
				let className = "list-group-item";
				let newMessage = false;
				if (this.props.activeUser && user.Id === this.props.activeUser.Id) {
					className += " active"
				} else {
					if (this.props.newMessage.userIds.includes(user.Id)) {
						newMessage = true;
					}
				}
				let userName = user.UserName;
				if (user.FirstName && user.LastName) {
					userName = user.FirstName + " " + user.LastName;
				}
				return (
					<li key={user.Id} className={className} onClick={() => this.props.changeCurrentUser(user.Id)}>
						{userName} {newMessage ? "Новое сообщение" : ""}
					</li>
				)
			});
			return (
				<div key={key} className="group">
					<h4 onClick={() => this.clickFunc(key)}>{this.catName(key)} ↓</h4>
					{(key === "newMessage" || this.state.showed.includes(key)) &&
						<ul className="list-group">
							{catUsers}
						</ul>
					}
				</div>
			)
		});

		return (
			<div className="Sidebar col-3">
				{categories}
			</div>
		);
	}
}

export default Sidebar;
