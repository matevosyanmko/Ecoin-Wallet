import React from 'react';
import "../../css/Order/Order.css"

class Order extends React.Component {
	constructor() {
		super();
		this.state = {
			showed: []
		};
	}

	statusClass(status) {
		switch (status) {
			case 1: return 'new';
			case 2: return 'refund';
			case 3: return 'failed';
			case 4: return 'success';
			default: return undefined;
		}
	};

	clickFunc(id) {
		if (!this.state.showed.includes(id)) {
			this.setState({
				showed: this.state.showed.concat([id])
			})
		} else {
			this.setState({
				showed: this.state.showed.filter(item => item !== id)
			})
		}
	}

	render() {
		if (!this.props.orderHistory) {
			return false;
		}
		let orderHistory = this.props.orderHistory.map((order) => {
			let statusClass = this.statusClass(order.OrderStatusID);
			let className = 'orderInfo';
			if (statusClass) {
				className += ' ' + statusClass
			}

			let OrderInfo = Object.keys(order).map(key => {
				return (
					<p key={key}>{key}: {order[key]}</p>
				)
			});

			return (
				<div className="order" key={order.Id}>
					<div className={className} onClick={() => this.clickFunc(order.Id)}>
						{order.Id} | {order.Title} | {order.Price}E | {order.PaymentTypeName} | {order.OrderStatusName} | {order.DateBegin} / {order.TimeBegin}
					</div>
					{this.state.showed.includes(order.Id) && <div className="jsonInfo">
						<pre>
							{OrderInfo}
						</pre>
					</div>}
				</div>
			);
		});
		return (
			<div className="Order">
				{orderHistory}
			</div>
		)
	}
}

export default Order;