import React from 'react';
import GlobalVariables from "../../GlobalVariables";
import "../../css/Order/CreateOrder.css";

class CreateOrder extends React.Component {
	constructor() {
		super();
		this.state = {
			activeCatSelect: null,
			activeProviderSelect: null,
			ProviderSelect: []
		};

		this.emptyOrder = [];
		this.addresses = [];

		this.handleServicesCatChange = this.handleServicesCatChange.bind(this);
		this.handleProviderChange = this.handleProviderChange.bind(this);
		this.submitEmptyOrder = this.submitEmptyOrder.bind(this);
	}

	handleServicesCatChange(event) {
		this.setState({
			activeCatSelect: event.target.value,
			activeProviderSelect: null
		});
	}

	handleProviderChange(event) {
		this.setState({
			activeProviderSelect: event.target.value
		});
	}

	componentWillMount() {
		GlobalVariables.getRequest('api/v1/partners/actual')
			.then((response) => {
				return response.json()
			})
			.then((response) => {
				this.setState({
					ProviderSelect: response
				})
			})
			.catch((error) => {
				alert(error)
			});
	}

	renderServiceOptions() {
		return this.state.ProviderSelect.map((provider) => {
			return (
				<option value={provider.Id} key={provider.Id}>
					{provider.Name}
				</option>
			)
		});
	}

	renderActiveCat() {
		if (this.state.activeCatSelect === "empty") {
			return (
				<div className="col-6">
					<div className="form-group">
						<select name="provider" className="form-control" id="provider"
						        onChange={(event) => this.handleProviderChange(event)}>
							<option value="">Выберите Исполнителя</option>
							{this.renderServiceOptions()}
						</select>
					</div>
				</div>
			)
		} else {
			return null;
		}
	}

	submitEmptyOrder() {
		let json = {};
		json.UserId = this.props.activeUser.Id;
		json.PaymentTypeCode = this.emptyOrder[0].value;
		json.Title = this.emptyOrder[1].value;
		json.Description = this.emptyOrder[2].value;
		json.Price = this.emptyOrder[3].value * 1;
		json.DateTimeBegin = this.emptyOrder[4].value;
		json.PartnerID = this.state.activeProviderSelect;
		if (this.state.activeCatSelect === 'empty') {
			json.Addresses = [];

			let addressArray = this.addresses.filter((address) => {
				return (address !== null);
			});

			addressArray.forEach((address, i) => {
				let obj = {};
				obj.Id = i + 1;
				obj.Address = address.value;
				obj.Longitude = 0;
				obj.Latitude = 0;
				json.Addresses.push(obj);
			});
		}

		GlobalVariables.postJson('api/v1/operator/order', json)
			.then((response) => {
				console.log(response);
				alert('Отправленно');
			})
			.catch((error) => {
				alert(error)
			});
	}

	renderProvider() {
		if (this.state.activeCatSelect === 'empty') {

			let emptyArray = new Array(1).fill(null);

			let addresses = emptyArray.map((a, i) => {
				return (
					<div className="form-group row" key={"address" + i}>
						<label htmlFor={"emptyAddress" + i} className="col-3 col-form-label">Адресс {i + 1}</label>
						<div className="col-8">
							<input className="form-control" type="text" id={"emptyAddress" + i}
							       name={"emptyAddress" + i} ref={e => this.addresses.push(e)}/>
						</div>
					</div>
				)
			});

			return (
				<div className="Form">
					<div className="row">
						<div className="col-12">
							<div className="form-group">
								<select name="emptyCash" className="form-control" id="emptyCash"
								        ref={e => this.emptyOrder.push(e)}>
									<option value="">Выберите тип оплаты</option>
									<option value="cash">Наличные</option>
									<option value="card">Карточка</option>
								</select>
							</div>
						</div>
					</div>
					<div className="form-group row">
						<label key="emptyTitle" htmlFor="emptyTitle" className="col-3 col-form-label">Заголовок</label>
						<div className="col-9">
							<input className="form-control" id="emptyTitle" type="text" name="emptyTitle"
							       ref={e => this.emptyOrder.push(e)}/>
						</div>
					</div>

					<div className="form-group row">
						<label key="emptyTitle" htmlFor="emptyDesc" className="col-3 col-form-label">Описание</label>
						<div className="col-9">
							<textarea className="form-control" name="emptyDesc" id="emptyDesc" rows="3"
							          ref={e => this.emptyOrder.push(e)}/>
						</div>
					</div>

					<div className="form-group row">
						<label key="emptyTitle" htmlFor="emptyPrice" className="col-3 col-form-label">Цена (в
							евро)</label>
						<div className="col-9">
							<input className="form-control" type="text" id="emptyPrice" name="emptyPrice"
							       ref={e => this.emptyOrder.push(e)}/>
						</div>
					</div>

					<div className="form-group row">
						<label key="emptyTitle" htmlFor="emptyDate" className="col-3 col-form-label">Время</label>
						<div className="col-9">
							<input className="form-control" type="datetime-local" id="emptyDate" name="emptyDate"
							       ref={e => this.emptyOrder.push(e)}/>
						</div>
					</div>
					{addresses}

					<input type="submit" className="btn btn-primary" onClick={() => this.submitEmptyOrder()}/>
				</div>
			)
		} else if (this.state.activeCatSelect === 'avia') {
			return (
				<iframe title="Aviasale" scrolling="no" width="620" height="255" frameBorder="0"
				        src="//www.travelpayouts.com/widgets/4c487f1b518af2f33b8cf56bf45a33c4.html?v=1379"/>
			);
		} else if (this.state.activeCatSelect === 'hotel') {
			return (
				<div className="Form">
					<iframe title="hotel" scrolling="no" width="620" height="255" frameBorder="0"
					        src="//www.travelpayouts.com/widgets/13eec6bce1e698741d0571ebaa6cb88f.html?v=1494"/>
				</div>
			);
		}
	}

	render() {
		return (
			<div className="CreateOrder">
				<div className="row spaceOrder">
					<div className="backgroundOrder col-12">
						<div className="row">
							<div className="col-6">
								<div className="form-group">
									<select name="servicesCat" className="form-control" id="servicesCat"
									        onChange={(event) => this.handleServicesCatChange(event)}>
										<option value="">Выберите категорию</option>
										<option value="empty">Универсальный заказ</option>
										<option value="avia">Авиабилеты</option>
										<option value="hotel">Отели</option>
									</select>
								</div>
							</div>
							{this.renderActiveCat()}
						</div>
						{this.renderProvider()}
					</div>
				</div>
			</div>
		);
	}

}

export default CreateOrder;